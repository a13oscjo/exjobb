#Installs the latest version of Chrome in the language specified in the parameter Language.

Configuration InstallChromeBrowser
{
    param
    (
	[Parameter(Mandatory)]
	$Language,
		
	[Parameter(Mandatory)]
	$LocalPath
		
    )
	
    Import-DscResource -module Chromeinstall
	
    chromeinstall chrome
    {
	Language = $Language
	LocalPath = $LocalPath
    }
}